<h3>
 This theme contains four custom page template[<strong style="color:green;">About , Contact , Pricing , Gallery</strong>]. Use those template while creating a page to adjust with keenshot theme design.
</h3>