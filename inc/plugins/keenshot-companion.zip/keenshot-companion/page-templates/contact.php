<?php
/**
 * The blog template file
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage keenshot
 * @since 1.0.0
 */

 get_header();
 

/**
 * @hoocked Contact Page Template Content
 */

 do_action('keenshot_contact_page_template_content');


/**
 * @hoocked Keenshot google map key
 */

 do_action('keenshot_google_map_key');

 get_footer(); 