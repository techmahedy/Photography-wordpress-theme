<?php 
/**
 * Keenshot about page template
 *
 * @link 
 *
 * @package Keenshot
 */

get_header();

do_action('keenshot_about_page_template_data');

$keenshot_page_section = array('skill','team','address','testimonial','map');

foreach ($keenshot_page_section as $section) {
     get_template_part( 'sections/'.$section); 
}
     
get_footer(); 