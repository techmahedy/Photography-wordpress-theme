<?php
/**
 * The blog template file
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage keenshot
 * @since 1.0.0
 */

 get_header();
 
/**
 * @hoocked Contact Page Template Content
 */

 do_action('keenshot_gallery_page_template_content');

 get_footer(); 