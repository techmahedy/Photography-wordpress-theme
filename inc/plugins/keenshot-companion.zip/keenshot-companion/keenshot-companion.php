<?php
/*
Plugin Name: Keenshot Companion
Plugin URI: 
Description: 
Version: 
Author: Keendevs
Author URI: 
License: GPLv2 or later
Text Domain: keenshot-companion
*/

defined('ABSPATH') or die('You silly man');

if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php' ) ) {
	require_once dirname( __FILE__ ) . '/vendor/autoload.php';
}

/**
 * @link included require plugin directory
 */

require plugin_dir_path( __FILE__ ) . '/widgets/keenshot-instagram.php';
require plugin_dir_path( __FILE__ ) . '/widgets/keenshot-recent-post.php';
require plugin_dir_path( __FILE__ ) . '/extras/extra.php';

/**
 * The code that runs during plugin activation
 */
function activate_kd_cpt_plugin(){
   Inc\Base\Activate::activate();
}
register_activation_hook(__FILE__, 'activate_kd_cpt_plugin');

/**
 * The code that runs during plugin deactivation
 */
function deactivate_kd_cpt_plugin(){
   Inc\Base\Deactivate::deactivate();
}
register_deactivation_hook(__FILE__, 'deactivate_kd_cpt_plugin');

if(class_exists('Inc\\Init')){
   Inc\Init::register_services();
}

