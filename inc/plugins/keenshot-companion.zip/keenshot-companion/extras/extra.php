<?php

 /**
  * Change default featured image text
  */
add_action( 'admin_head', 'replace_keenshot_gallery_feature_image', 100 );
  function replace_keenshot_gallery_feature_image() {
		remove_meta_box( 'postimagediv', 'gallery', 'side' );
		add_meta_box('postimagediv', __('Add gallery Image'), 'post_thumbnail_meta_box', 'gallery', 'side', 'high');
}

/**
 * Keenshot Get Page Template Link
 */
function keenshot_get_page_template_link($temp){
   $link = null;
   $pages = get_pages(
     array(
       'meta_key' => '_wp_page_template',
       'meta_value' => $temp
     )
   );
   if(isset($pages[0])){
     $link = get_page_link($pages[0]->ID);
   }
   return $link;
 }

