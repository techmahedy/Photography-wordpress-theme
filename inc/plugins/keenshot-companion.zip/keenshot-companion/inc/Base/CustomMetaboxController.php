<?php 
/**
 * @package  Keenshot Companion
 */
namespace Inc\Base;
use Inc\Base\BaseController;

class CustomMetaboxController extends BaseController
{
    public function register() {
		add_action( 'init', array( $this, 'activate' ) );
	}
    public function activate(){
        add_action('add_meta_boxes', function(){
          add_meta_box( 'price', 'Price', [$this, 'gallery_price'],'gallery');
          add_meta_box( 'description', 'Description', [$this, 'gallery_description'],'gallery');
        });
       
        add_action('save_post',function($id){
            if (isset($_POST['price']) && isset($_POST['description'])) {
                update_post_meta( $id, 'price',strip_tags($_POST['price']));
                update_post_meta( $id, 'description',strip_tags($_POST['description']));
             }
        });

    }

        function gallery_price($post){
          $price = get_post_meta($post->ID,'price',true);
       
       ?>
         <p>
            <label for="price">Price</label>
            <input type="text" name="price" class="widefat" id="price" value="<?php esc_attr_e( $price, 'gallery' ); ?>" />
         </p>
       <?php
        }

        function gallery_description($post){
            $description = get_post_meta($post->ID,'description',true);
       
       ?>
         <p>
            <label for="description">Description</label>
            <input type="text" name="description" class="widefat" id="description" value="<?php esc_attr_e( $description, 'gallery' ); ?>" />
         </p>
       <?php
    }

}

