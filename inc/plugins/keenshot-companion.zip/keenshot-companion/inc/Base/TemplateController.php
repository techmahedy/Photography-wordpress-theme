<?php 
/**
 * @package  Keenshot Companion
 */
namespace Inc\Base;

use Inc\Api\SettingsApi;
use Inc\Base\BaseController;
use Inc\Api\Callbacks\CptCallbacks;
use Inc\Api\Callbacks\AdminCallbacks;

class TemplateController extends BaseController
{
	public $templates;
	public $settings;
	public $callbacks;
	public $cpt_callbacks;
	public $subpages = array();
	public $custom_post_types = array();

	public function register()
	{
		if ( ! $this->activated( 'templates_manager' ) ) return;
		
		$this->settings = new SettingsApi();
		$this->callbacks = new AdminCallbacks();
		$this->setSubpages();
		$this->settings->addSubPages( $this->subpages )->register();

		$this->templates = array(
			'page-templates/gallery.php' => 'Gallery',
			'page-templates/pricing.php' => 'Pricing',
			'page-templates/about.php' => 'About',
			'page-templates/contact.php' => 'Contact',
		);

		add_filter( 'theme_page_templates', array( $this, 'custom_template' ) );
		add_filter( 'template_include', array( $this, 'load_template' ) );
	}

	public function setSubpages()
	{
		$this->subpages = array(
			array(
				'parent_slug' => 'kd_cpt_plugin', 
				'page_title' => 'Template Manager', 
				'menu_title' => 'Template Manager', 
				'capability' => 'manage_options', 
				'menu_slug' => 'template_manager', 
				'callback' => array( $this->callbacks, 'adminTemplate' )
			)
		);
	}

	public function custom_template( $templates )
	{
		$templates = array_merge( $templates, $this->templates );
		return $templates;
	}
	public function load_template( $template )
	{
		global $post;
		if ( ! $post ) {
			return $template;
		}
		$template_name = get_post_meta( $post->ID, '_wp_page_template', true );
		if ( ! isset( $this->templates[$template_name] ) ) {
			return $template;
		}
		$file = $this->plugin_path . $template_name;
		if ( file_exists( $file ) ) {
			return $file;
		}
		return $template;
	}
}