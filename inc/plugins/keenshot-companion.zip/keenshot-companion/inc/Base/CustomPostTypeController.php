<?php 
/**
 * @package  Keenshot Companion
 */
namespace Inc\Base;

use Inc\Base\BaseController;

class CustomPostTypeController extends BaseController
{

	public function register() {

		if ( ! $this->activated( 'cpt_manager' ) ) return;
		add_action( 'init', array( $this, 'keenshop_register_custom_post' ) );
	}

	public function keenshop_register_custom_post()
	{
		register_post_type( 'gallery',
			array(
				'labels' => array(
					'name' => __('Gallery','keenshot-companion'),
					'singular_name' => __('Gallery','keenshot-companion'),
					'add_new' => __('Add New Gallery','keenshot-companion'),
					'add_new_item' => __('Add New Gallery','keenshot-companion'),
					'edit_item' => __('Edit Gallery','keenshot-companion'),
					'new_item' => __('Add New Gallery','keenshot-companion'),
					'view_item' => __('View Gallery','keenshot-companion'),
					'search_items' => __('Search Gallery','keenshot-companion'),
					'not_found' => __('No Gallery Found','keenshot-companion'),
					'not_found_in_trash' => __('No Gallery Found in Trach','keenshot-companion')
	
				),
				'query_var' => true,
				'rewrite' => array(
				   'slug' => 'gallery',
				),
				'public' => true,
				'menu_position' => 15,
				'supports' => array(
				   'title',
				   'thumbnail',
				   'excerpt', 
				   'editor',
				   'comments'         
				),
				'has_archive' => true,
				'taxonomies' => ['cat'],
				'exclude_from_search' => false,
                'publicly_queryable' => true,
                'show_in_nav_menus' => true,
				'show_ui' => true,
				'hierarchical' => false,
				
			)
		);
	}
}


