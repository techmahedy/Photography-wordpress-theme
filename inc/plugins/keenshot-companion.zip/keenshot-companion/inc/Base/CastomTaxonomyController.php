<?php 
/**
 * @package  Keenshot Companion
 */
namespace Inc\Base;

use Inc\Base\BaseController;

class CastomTaxonomyController extends BaseController
{
	
	public function register() {
		add_action( 'init', array( $this, 'activate_cpt_taxonomy' ) );
	}

	public function activate_cpt_taxonomy()
	{
		$taxonomies = array();

    	$taxonomies['cat'] = array(
           'query_var' => true,
           'rewrite' => true,
           'labels' => array(
                'name' => __('Category','keenshot-companion'),
                'singular_name' => __('Category','keenshot-companion'),
                'edit_item' => __('Edit Category','keenshot-companion'),
                'update_item' => __('Edit Category','keenshot-companion'),
                'add_new_item' => __('Add New Category','keenshot-companion'),
                'new_item_name' => __('Add New Category','keenshot-companion'),
                'all_items' => __('All Categories','keenshot-companion'),
                'search_items' => __('Search Category','keenshot-companion'),
                'popular_items' => __('Popular Category','keenshot-companion'),
                'separate_items_with_commnets' => __('Separate categories with commas','keenshot-companion'),
                'add_or_remove_item' => __('Add or Remove Category','keenshot-companion'),
                'choose_from_most_used' =>__('Choose from most used category','keenshot-companion'),
                'has_archive' => true,
                'exclude_from_search' => false,
                'publicly_queryable' => true,
                'show_in_nav_menus' => true,
                'show_ui' => true,
           )
    	   );

    	   $this->register_all_taxonomies($taxonomies);
    }
    
    public function register_all_taxonomies($taxonomies){
        foreach ($taxonomies as $key => $arr) {
           register_taxonomy($key , array('gallery'),$arr);
       }
    }
}
