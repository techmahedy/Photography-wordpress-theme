<?php
/**
 * @package  Keenshot Companion
 */

namespace Inc\Base;

class BaseController {

    public $plugin_path , $plugin_url , $plugin_name;
    public $managers = array();

    public function __construct(){
        $this->plugin_path = plugin_dir_path(dirname(__FILE__ , 2 )); // Define plugin directory path
        $this->plugin_url = plugin_dir_url(dirname(__FILE__ , 2 )); // Define plugin directory url
        $this->plugin_name = plugin_basename(dirname(__FILE__ , 3 )) . '/keenshot-companion.php'; // Getting plugin name

        $this->managers = array(
          'cpt_manager' => 'Activate Custom Post Type',		 
          'templates_manager' => 'Activate Custom Page Template',
		   );
    }

    public function activated( string $key ) {

        $option = get_option( 'kd_cpt_plugin' );
        
		    return isset( $option[ $key ] ) ? $option[ $key ] : false;
	  }
}
